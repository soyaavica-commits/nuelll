# Kado
-Flower code from: https://codepen.io/mdusmanansari/pen/BamepLe



view : https://raihannafisz.github.io/bunga/

# Description
Flower code tiktok trend 

Responsive Web -- bisa langsung disesuikan di file css --> style.css


Thanks to codepan and mdusmanansari
